
function deleteTicket(){

if(confirm("Are u sure")){
	alert("Deleted successfully");
	return true;
}
else{
	return false;
}
}