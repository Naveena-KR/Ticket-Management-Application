#------------------------Graded Assignment for Spring Boot Maven--------------------------
create database SpringMVCMavenTicketTrackerApplication;
use SpringMVCMavenTicketTrackerApplication;
select*from ticket;